package com.open.autopkg;

import com.open.autopkg.ui.MainUI;

public class Main {

	public static void main(String[] args)
	{
		MainUI mMainUI=new MainUI();
		mMainUI.show();
	}

}
