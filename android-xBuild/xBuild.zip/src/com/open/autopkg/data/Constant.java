package com.open.autopkg.data;

public class Constant 
{
	
			public static final String  URL_UPLOAD 			= "http://172.20.133.58:80/AutoPackage/test.php";
			public static final String URL_ADMIN 			= "http://365.oa.com/admin/index.php?_action=welcome/index";
			public static final String URL_ADMIN_DEV 	= "http://365.oa.com/admin-dev/index.php?_action=welcome/index";

}
